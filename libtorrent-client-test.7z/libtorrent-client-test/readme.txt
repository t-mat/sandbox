﻿libtorrent 0.15.9 と boost 1.40.0 を使って libtorrent のサンプルコード client_test を動かす
===========================================================================================

この readme.txt ファイルがあるディレクトリに

	boost_1_40_0.7z
	libtorrent-rasterbar-0.15.9.tar.gz

を配置し、

	https://gist.github.com/1581005

にある方法に従って、boost と libtorrent のビルドを行ってください。

その後、client-test\client_test.sln を VisualC++ 2010 で開き、
ビルド、デバッグ実行を行うと、client_test が実行され、
ubuntu-11.10 の ISO イメージのダウンロードが開始されます。

ダウンロードしたファイルは client-test\ 以下に保存されます。
